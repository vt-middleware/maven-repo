/* See LICENSE for licensing and NOTICE for copyright. */
package org.ldaptive;

/**
 * LDAP modification defined as:
 *
 * <pre>
   modification    PartialAttribute

   PartialAttribute ::= SEQUENCE {
     type       AttributeDescription,
     vals       SET OF value AttributeValue }
 * </pre>
 *
 * @author  Middleware Services
 */
public class AttributeModification
{
  /** Modification type. */
  public enum Type {

    /** Add a new attribute. */
    ADD,

    /** Delete an attribute. */
    DELETE,

    /** Replace an attribute. */
    REPLACE,

    /** Increment the value of an attribute. */
    INCREMENT,
  }

  /** Modification type. */
  private final Type operation;

  /** Attribute to modify. */
  private final LdapAttribute attribute;


  /**
   * Creates a new modification.
   *
   * @param  type  of modification
   * @param  attr  attribute to modify
   */
  public AttributeModification(final Type type, final LdapAttribute attr)
  {
    operation = LdapUtils.assertNotNullArg(type, "Modification type cannot be null");
    attribute = LdapUtils.assertNotNullArgOr(
      attr, a -> a.getName() == null, "Modification attribute cannot be null or have a null name");
  }


  /**
   * Returns the operation type.
   *
   * @return  operation type
   */
  public Type getOperation()
  {
    return operation;
  }


  /**
   * Sets the operation type.
   *
   * @return  operation type
   */
  public LdapAttribute getAttribute()
  {
    return attribute;
  }


  @Override
  public String toString()
  {
    return getClass().getName() + "@" + hashCode() + "::" + "operation=" + operation + ", " + "attribute=" + attribute;
  }
}
