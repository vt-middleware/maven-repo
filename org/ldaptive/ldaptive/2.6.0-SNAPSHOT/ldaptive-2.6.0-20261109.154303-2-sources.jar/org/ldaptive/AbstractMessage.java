/* See LICENSE for licensing and NOTICE for copyright. */
package org.ldaptive;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.ldaptive.asn1.AbstractParseHandler;
import org.ldaptive.asn1.BooleanType;
import org.ldaptive.asn1.DERBuffer;
import org.ldaptive.asn1.DERParser;
import org.ldaptive.asn1.DERPath;
import org.ldaptive.asn1.DERReader;
import org.ldaptive.asn1.DERTag;
import org.ldaptive.asn1.IntegerType;
import org.ldaptive.asn1.OctetStringType;
import org.ldaptive.asn1.UniversalDERTag;
import org.ldaptive.control.ControlFactory;
import org.ldaptive.control.ResponseControl;

/**
 * LDAP message envelope defined as:
 *
 * <pre>
   LDAPMessage ::= SEQUENCE {
     messageID       MessageID,
     protocolOp      CHOICE {
       ...,
     controls       [0] Controls OPTIONAL }

   Control ::= SEQUENCE {
     controlType             LDAPOID,
     criticality             BOOLEAN DEFAULT FALSE,
     controlValue            OCTET STRING OPTIONAL }
 * </pre>
 *
 * @author  Middleware Services
 */
public abstract class AbstractMessage implements Message
{

  /** LDAP controls. */
  private final List<ResponseControl> controls = new ArrayList<>();

  /** Protocol message ID. */
  private int messageID;


  @Override
  public final int getMessageID()
  {
    return messageID;
  }


  /**
   * Sets the message ID.
   *
   * @param  id  of the message
   */
  protected void setMessageID(final int id)
  {
    messageID = id;
  }


  @Override
  public final ResponseControl[] getControls()
  {
    return controls != null ? controls.toArray(new ResponseControl[0]) : null;
  }


  /**
   * Adds the supplied controls to this message.
   *
   * @param  cntrls  to add
   */
  protected final void addControls(final ResponseControl... cntrls)
  {
    Collections.addAll(controls, cntrls);
  }


  /**
   * Copies the property values from the supplied message to this message.
   *
   * @param  <T>  type of message
   * @param  message  to copy from
   */
  protected <T extends Message> void copyValues(final T message)
  {
    setMessageID(message.getMessageID());
    addControls(message.getControls());
  }


  /**
   * Returns whether the base properties of this message are equal. Those include message ID and controls.
   *
   * @param  message  to compare
   *
   * @return  whether message properties are equal
   */
  public final boolean equalsMessage(final Message message)
  {
    if (message == this) {
      return true;
    }
    return LdapUtils.areEqual(getMessageID(), message.getMessageID()) &&
      LdapUtils.areEqual(getControls(), message.getControls());
  }


  // CheckStyle:EqualsHashCode OFF
  @Override
  public boolean equals(final Object o)
  {
    if (o == this) {
      return true;
    }
    if (o instanceof AbstractMessage) {
      final AbstractMessage v = (AbstractMessage) o;
      return LdapUtils.areEqual(getMessageID(), v.getMessageID()) &&
        LdapUtils.areEqual(getControls(), v.getControls());
    }
    return false;
  }
  // CheckStyle:EqualsHashCode ON


  /**
   * Returns the hash code for this object.
   *
   * @return  hash code
   */
  @Override
  public abstract int hashCode();


  @Override
  public String toString()
  {
    return getClass().getName() + "@" + System.identityHashCode(this) + "::" +
      "messageID=" + messageID + ", " + "controls=" + controls;
  }


  /**
   * Parse handler that validates whether it was invoked.
   *
   * @param  <T>  type of object validated by this handler
   */
  protected abstract static class AbstractValidatingParseHandler<T> extends AbstractParseHandler<T>
  {
    /** Validation failure message. */
    private final String message;

    /** Whether a {@link #handle(DERParser, DERBuffer)} was invoked. */
    private boolean invoked;


    /**
     * Creates a new abstract parse handler.
     *
     * @param  t  object to initialize
     * @param  msg  to report on failure
     */
    public AbstractValidatingParseHandler(final T t, final String msg)
    {
      super(t);
      message = msg;
    }


    @Override
    public void handle(final DERParser parser, final DERBuffer encoded)
    {
      invoked = true;
    }


    @Override
    public Runnable validator()
    {
      return () -> {
        if (!invoked) {
          throw new IllegalArgumentException(message);
        }
      };
    }
  }


  /** Parse handler implementation for the protocol op. */
  protected static class ProtocolOpHandler extends AbstractValidatingParseHandler<AbstractMessage>
  {


    /**
     * Creates a new protocol OP handler.
     *
     * @param  response  to configure
     */
    public ProtocolOpHandler(final AbstractMessage response)
    {
      super(response, "Protocol OP not found");
    }
  }


  /** Parse handler implementation for the message ID. */
  protected static class MessageIDHandler extends AbstractValidatingParseHandler<AbstractMessage>
  {

    /** DER path to message id. */
    public static final DERPath PATH = new DERPath("/SEQ/INT[0]");


    /**
     * Creates a new message ID handler.
     *
     * @param  response  to configure
     */
    public MessageIDHandler(final AbstractMessage response)
    {
      super(response, "Message ID not found");
    }


    @Override
    public void handle(final DERParser parser, final DERBuffer encoded)
    {
      super.handle(parser, encoded);
      getObject().setMessageID(IntegerType.decodeUnsignedPrimitive(encoded));
    }
  }


  /** Parse handler implementation for the message controls. */
  protected static class ControlsHandler extends AbstractParseHandler<AbstractMessage>
  {

    /** DER path to controls. */
    public static final DERPath PATH = new DERPath("/SEQ/CTX(0)/SEQ");


    /**
     * Creates a new controls handler.
     *
     * @param  response  to configure
     */
    public ControlsHandler(final AbstractMessage response)
    {
      super(response);
    }


    @Override
    public void handle(final DERParser parser, final DERBuffer encoded)
    {
      final ControlParser p = new ControlParser();
      p.parse(encoded);
      if (p.getOid().isEmpty()) {
        throw new IllegalArgumentException("Cannot parse response control without OID for buffer " + encoded);
      }
      getObject().addControls(
        ControlFactory.createResponseControl(
          p.getOid().get(),
          p.getCritical().isPresent() ? p.getCritical().get() : false,
          p.getValue().isPresent() ? p.getValue().get() : null));
    }
  }


  /**
   * Parses a buffer containing an LDAP control.
   */
  protected static class ControlParser
  {
    /** Control criticality. */
    private Boolean critical;

    /** Control oid. */
    private String oid;

    /** Control value. */
    private DERBuffer value;


    /**
     * Creates a new control parser.
     */
    public ControlParser() {}


    /**
     * Examines the supplied buffer and parses an LDAP control if one is found.
     *
     * @param  buffer  to parse
     */
    public void parse(final DERBuffer buffer)
    {
      final int limit = buffer.limit();
      int index = 0;
      while (buffer.position() < limit) {
        final DERTag tag = DERReader.readTag(buffer);
        final int end = DERReader.readEnd(tag, buffer, limit);
        if (tag == UniversalDERTag.OCTSTR) {
          if (index == 0) {
            oid = OctetStringType.decode(buffer);
          } else if (index == 1) {
            if (critical == null) {
              value = buffer.slice();
            } else {
              throw new IllegalArgumentException("Invalid control tag: " + tag + " at index " + index);
            }
          } else if (index == 2) {
            if (value == null) {
              value = buffer.slice();
            } else {
              throw new IllegalArgumentException("Invalid control tag: " + tag + " at index " + index);
            }
          } else {
            throw new IllegalArgumentException("Invalid control tag: " + tag + " at index " + index);
          }
        } else if (tag == UniversalDERTag.BOOL) {
          if (index == 1) {
            critical = BooleanType.decode(buffer);
          } else {
            throw new IllegalArgumentException("Invalid control tag: " + tag + " at index " + index);
          }
        } else {
          throw new IllegalArgumentException("Invalid control tag: " + tag);
        }
        buffer.positionAndLimit(end, limit);
        index++;
      }
    }


    /**
     * Returns the control criticality.
     *
     * @return  criticality or empty
     */
    public Optional<Boolean> getCritical()
    {
      return Optional.ofNullable(critical);
    }


    /**
     * Returns the control oid.
     *
     * @return  control oid or empty
     */
    public Optional<String> getOid()
    {
      return Optional.ofNullable(oid);
    }


    /**
     * Returns the control value.
     *
     * @return  control value or empty
     */
    public Optional<DERBuffer> getValue()
    {
      return Optional.ofNullable(value);
    }
  }


  // CheckStyle:OFF
  protected abstract static class AbstractBuilder<B, T extends AbstractMessage>
  {

    protected final T object;


    protected AbstractBuilder(final T t)
    {
      object = t;
    }


    protected abstract B self();


    public B messageID(final int id)
    {
      object.setMessageID(id);
      return self();
    }


    public B controls(final ResponseControl... controls)
    {
      object.addControls(controls);
      return self();
    }


    public B copy(final Message m)
    {
      object.copyValues(m);
      return self();
    }


    public T build()
    {
      return object;
    }
  }
  // CheckStyle:ON
}
