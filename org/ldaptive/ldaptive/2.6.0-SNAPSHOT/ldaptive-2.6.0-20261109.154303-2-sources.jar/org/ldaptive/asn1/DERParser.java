/* See LICENSE for licensing and NOTICE for copyright. */
package org.ldaptive.asn1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * This class provides a SAX-like parsing facility for DER-encoded data where elements of interest in the parse tree may
 * be registered to handlers via the {@link #registerHandler} methods. {@link DERPath} strings are used to map handlers
 * to elements of interest.
 *
 * @author  Middleware Services
 * @see  DERPath
 */
public final class DERParser
{

  /** Maximum supported path depth. */
  private static final int MAX_PATH_DEPTH = 16;

  /** Number of available tag numbers for application and context tags. (5 bits) */
  private static final int TAG_NUMBERS = 32;

  /** Application tags indexed by constructed flag and tag number. */
  private static final DERTag[][] APPLICATION_TAGS = new DERTag[2][TAG_NUMBERS];

  /** Context tags indexed by constructed flag and tag number. */
  private static final DERTag[][] CONTEXT_TAGS = new DERTag[2][TAG_NUMBERS];

  /** Root node for the tree of registered handler paths. */
  private final PathNode root = new PathNode(null, PathNode.ANY_INDEX);

  /**
   * Reusable lists of matching path nodes, indexed by depth. Matches at a depth are only needed until the next sibling
   * tag is read, so one list per depth is sufficient.
   */
  private final List<List<PathNode>> matchesByDepth = new ArrayList<>(MAX_PATH_DEPTH);

  /** Whether any handler has been registered. */
  private boolean hasHandlers;

  /** Handler validators. */
  private final List<Runnable> handlerValidators = new ArrayList<>();

  // initialize application and context tag arrays
  static {
    for (int i = 0; i < TAG_NUMBERS; i++) {
      APPLICATION_TAGS[0][i] = new ApplicationDERTag(i, false);
      APPLICATION_TAGS[1][i] = new ApplicationDERTag(i, true);
      CONTEXT_TAGS[0][i] = new ContextDERTag(i, false);
      CONTEXT_TAGS[1][i] = new ContextDERTag(i, true);
    }
  }


  /**
   * Registers the supplied handler to fire when the supplied path is encountered.
   *
   * @param  path  to register
   * @param  handler  to associate with the path
   */
  public void registerHandler(final DERPath path, final ParseHandler handler)
  {
    PathNode node = root;
    for (DERPath.Node n : path.getNodes()) {
      node = node.addChild(n.getName(), n.getChildIndex());
    }
    node.handler = handler;
    hasHandlers = true;
    final Runnable validator = handler.validator();
    if (validator != null) {
      handlerValidators.add(validator);
    }
  }


  /**
   * Parse a DER-encoded data structure by calling registered handlers when points of interest are encountered in the
   * parse tree.
   *
   * @param  encoded  DER-encoded bytes.
   */
  public void parse(final DERBuffer encoded)
  {
    if (encoded == null) {
      throw new IllegalArgumentException("Buffer cannot be null");
    }
    parseTags(encoded, Collections.singletonList(root), 1);
    for (Runnable runnable : handlerValidators) {
      runnable.run();
    }
  }


  /**
   * Reads a DER tag from a single byte at the current position of the given buffer. The buffer position is naturally
   * advanced one byte in this operation.
   *
   * @param  encoded  Buffer containing DER-encoded bytes positioned at tag.
   *
   * @return  Tag or null if no universal tag or application-specific tag is known that matches the byte read in.
   */
  public DERTag readTag(final DERBuffer encoded)
  {
    if (encoded == null) {
      throw new IllegalArgumentException("Buffer cannot be null");
    }
    if (encoded.position() >= encoded.limit()) {
      return null;
    }

    final DERTag tag;
    final byte b = encoded.get();
    // CheckStyle:MagicNumber OFF
    final int tagNo = b & 0x1F;
    final boolean constructed = (b & 0x20) == 0x20;
    // Read class from first two high-order bits
    switch (b & 0xC0) {

    case UniversalDERTag.TAG_CLASS:
      tag = UniversalDERTag.fromTagNo(tagNo);
      break;

    case ApplicationDERTag.TAG_CLASS:
      tag = APPLICATION_TAGS[constructed ? 1 : 0][tagNo];
      break;

    case ContextDERTag.TAG_CLASS:
      tag = CONTEXT_TAGS[constructed ? 1 : 0][tagNo];
      break;

    default:
      // Private class (class 11b)
      throw new IllegalArgumentException("Private classes not supported.");
    }
    // CheckStyle:MagicNumber ON
    return tag;
  }


  /**
   * Reads the length of a DER-encoded value from the given byte buffer. The buffer is expected to be positioned at the
   * byte immediately following the tag byte, which is where the length byte(s) begin(s). Invocation of this method has
   * two generally beneficial side effects:
   *
   * <ol>
   *   <li>Buffer is positioned at <em>start</em> of value bytes.</li>
   *   <li>Buffer limit is set to the <em>end</em> of value bytes.</li>
   * </ol>
   *
   * @param  encoded  buffer containing DER-encoded bytes positioned at start of length byte(s).
   *
   * @return  number of bytes occupied by tag value.
   */
  public int readLength(final DERBuffer encoded)
  {
    if (encoded == null) {
      throw new IllegalArgumentException("Buffer cannot be null");
    }
    final int length;
    final byte b = encoded.get();
    // CheckStyle:MagicNumber OFF
    if ((b & 0x80) == 0x80) {
      final int len = b & 0x7F;
      if (len < 1 || len > 4) {
        throw new IllegalArgumentException("Invalid length: " + len + " at position " + encoded.position());
      }
      final int limit = encoded.limit();
      encoded.limit(encoded.position() + len);
      length = IntegerType.decodeUnsignedPrimitive(encoded);
      encoded.limit(limit);
    } else {
      length = b;
    }
    if (length < 0) {
      throw new IllegalArgumentException("Invalid length: " + length + " at position " + encoded.position());
    }
    // CheckStyle:MagicNumber ON
    return length;
  }


  /**
   * Reads the supplied DER encoded bytes and invokes handlers as configured paths are encountered.
   *
   * @param  encoded  to parse
   * @param  parents  registered path nodes that match the parent of the tags being read
   * @param  depth  of the tags being read, top level tags have a depth of 1
   */
  private void parseTags(final DERBuffer encoded, final List<PathNode> parents, final int depth)
  {
    int index = 0;
    while (encoded.position() < encoded.limit() && hasHandlers) {
      final DERTag tag = readTag(encoded);
      if (tag != null) {
        if (depth > MAX_PATH_DEPTH) {
          throw new IllegalArgumentException("Maximum path depth exceeded");
        }
        parseTag(tag, encoded, matchTag(tag, index++, parents, depth), depth);
      }
    }
  }


  /**
   * Invokes the parse handlers for the current path and advances to the next position in the encoded bytes.
   *
   * @param  tag  to inspect for internal tags
   * @param  encoded  to parse
   * @param  matches  registered path nodes that match the current path
   * @param  depth  of the tag
   */
  private void parseTag(final DERTag tag, final DERBuffer encoded, final List<PathNode> matches, final int depth)
  {
    final int limit = encoded.limit();
    final int lengthPos = encoded.position();
    final int length;
    try {
      length = readLength(encoded);
    } catch (Exception e) {
      throw new IllegalArgumentException("Could not parse length of tag " + tag + " at position " + lengthPos, e);
    }
    final int end = length + encoded.position();
    final int start = encoded.position();

    if (end > limit) {
      throw new IllegalArgumentException(
        "Tag " + tag + " with length " + length + " at position " + encoded.position() + " exceeds limit " + limit);
    }

    for (PathNode node : matches) {
      if (node.handler != null) {
        encoded.positionAndLimit(start, end);
        node.handler.handle(this, encoded);
      }
    }

    // tags with no matching path are still parsed in order to validate the encoding
    if (tag.isConstructed()) {
      parseTags(encoded.positionAndLimit(start, end), matches, depth + 1);
    }
    encoded.positionAndLimit(end, limit);
  }


  /**
   * Returns the registered path nodes that match the supplied tag. A tag matches a child node with the same name that
   * either has the same child index as the tag or has no child index. Children with a matching child index are ordered
   * before children with no child index, so handlers for the more specific path are invoked first.
   *
   * @param  tag  to match
   * @param  index  of the tag relative to its parent
   * @param  parents  registered path nodes that match the parent of the tag
   * @param  depth  of the tag
   *
   * @return  matching path nodes
   */
  private List<PathNode> matchTag(final DERTag tag, final int index, final List<PathNode> parents, final int depth)
  {
    boolean hasChildren = false;
    for (PathNode parent : parents) {
      if (parent.hasChildren()) {
        hasChildren = true;
        break;
      }
    }
    if (!hasChildren) {
      return Collections.emptyList();
    }
    while (matchesByDepth.size() < depth) {
      matchesByDepth.add(new ArrayList<>());
    }
    final List<PathNode> matches = matchesByDepth.get(depth - 1);
    matches.clear();
    final String name = tag.name();
    for (PathNode pathNode : parents) {
      pathNode.addChildTo(name, index, matches);
    }
    for (PathNode pathNode : parents) {
      pathNode.addChildTo(name, PathNode.ANY_INDEX, matches);
    }
    return matches;
  }


  /** Node in the tree of registered handler paths. */
  private static final class PathNode
  {
    /** Child index of a path node that matches a tag at any index. */
    private static final int ANY_INDEX = -1;

    /** Empty children. */
    private static final PathNode[] NO_CHILDREN = new PathNode[0];

    /** Tag name. */
    private final String name;

    /** Child index of the tag or {@link #ANY_INDEX}. */
    private final int childIndex;

    /** Child nodes. Paths have few children per node, linear search. */
    private PathNode[] children = NO_CHILDREN;

    /** Handler to invoke when the path to this node is encountered. */
    private ParseHandler handler;


    /**
     * Creates a new path node.
     * @param  n  tag name
     * @param  i  child index of the tag or {@link #ANY_INDEX}
     */
    PathNode(final String n, final int i)
    {
      name = n;
      childIndex = i;
    }


    /**
     * Returns whether this node has any children.
     *
     * @return  whether this node has any children
     */
    boolean hasChildren()
    {
      return children.length > 0;
    }


    /**
     * Returns the child with the supplied name and child index, creating it if it does not exist.
     *
     * @param  n  name of the tag
     * @param  i  child index of the tag or {@link #ANY_INDEX}
     *
     * @return  existing child node if found, otherwise new child node
     */
    PathNode addChild(final String n, final int i)
    {
      final PathNode existing = getChild(n, i);
      if (existing != null) {
        return existing;
      }
      final PathNode child = new PathNode(n, i);
      children = Arrays.copyOf(children, children.length + 1);
      children[children.length - 1] = child;
      return child;
    }


    /**
     * Adds the child with the supplied name and child index to the supplied list if it exists.
     *
     * @param  n  name of the tag
     * @param  i  child index of the tag or {@link #ANY_INDEX}
     * @param  nodes  to add the child to
     *
     */
    void addChildTo(final String n, final int i, final List<PathNode> nodes)
    {
      final PathNode child = getChild(n, i);
      if (child != null) {
        nodes.add(child);
      }
    }


    /**
     * Returns the child with the supplied name and child index.
     *
     * @param  n  name of the tag
     * @param  i  child index of the tag or {@link #ANY_INDEX}
     *
     * @return  child node or null if no child exists
     */
    private PathNode getChild(final String n, final int i)
    {
      for (PathNode child : children) {
        if (child.childIndex == i && child.name.equals(n)) {
          return child;
        }
      }
      return null;
    }
  }
}
