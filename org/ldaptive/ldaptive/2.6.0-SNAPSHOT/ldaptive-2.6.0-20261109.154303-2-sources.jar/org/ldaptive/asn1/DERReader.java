/* See LICENSE for licensing and NOTICE for copyright. */
package org.ldaptive.asn1;

/**
 * Provides utility methods for reading data from a {@link DERBuffer}.
 *
 * @author  Middleware Services
 */
public final class DERReader
{
  /** Parser used to read tags and lengths. Reading tags and lengths does not use parser state. */
  private static final DERParser PARSER = new DERParser();


  /** Default constructor. */
  private DERReader() {}


  /**
   * Read a tag from the supplied buffer. See {@link DERParser#readTag(DERBuffer)}.
   *
   * @param  buffer  to read
   *
   * @return  DER tag
   */
  public static DERTag readTag(final DERBuffer buffer)
  {
    return PARSER.readTag(buffer);
  }


  /**
   * Read a length from the supplied buffer. See {@link DERParser#readLength(DERBuffer)}.
   *
   * @param  buffer  to read
   *
   * @return  length
   */
  public static int readLength(final DERBuffer buffer)
  {
    return PARSER.readLength(buffer);
  }


  /**
   * Reads the length of the supplied tag and limits the buffer to the tag value.
   *
   * @param  tag  whose length is read
   * @param  buffer  positioned at the start of the length
   * @param  limit  that the tag value cannot exceed
   *
   * @return  position of the end of the tag value
   *
   * @throws  IllegalArgumentException  if the length cannot be read or exceeds the limit
   */
  public static int readEnd(final DERTag tag, final DERBuffer buffer, final int limit)
  {
    final int lengthPos = buffer.position();
    final int length;
    try {
      length = PARSER.readLength(buffer);
    } catch (Exception e) {
      throw new IllegalArgumentException("Could not parse length of tag " + tag + " at position " + lengthPos, e);
    }
    final int end = buffer.position() + length;
    if (end > limit) {
      throw new IllegalArgumentException(
        "Tag " + tag + " with length " + length + " at position " + buffer.position() + " exceeds limit " + limit);
    }
    buffer.limit(end);
    return end;
  }
}
